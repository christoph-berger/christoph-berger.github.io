# =============================================================================
# 03_ausblick_cosinor_paket.R – Ausblick, im Workshop NICHT ausführen
# =============================================================================
# Das Mixed-Cosinor-Modell aus 02 (Schritt 5) gibt es auch fertig verpackt im
# Paket cosinoRmixedeffects (GitHub, nicht CRAN). Es rechnet dasselbe lmer-
# Modell und liefert Konfidenzintervalle per parametrischem Bootstrap.
#
# Warum nicht im Workshop?
#   - Nur über GitHub installierbar.
#   - Der Bootstrap passt das Modell nsim-mal neu an (Standard 500):
#     bei TVR_11 rund 2–3 Sekunden pro Durchlauf → 20+ Minuten.
#   - get.contrasts.ci.cosinor() ruft intern doMC::registerDoMC(8) auf.
#     doMC gibt es unter Windows nicht – die Funktion bricht dort ab.
#
# Einheiten-Falle: Die Akrophase kommt in RADIANT zurück (−2π … 0).
# Die zusätzliche Zeile "PeakTime" ist dieselbe Größe in Stunden:
#   PeakTime = −Akrophase · 24 / (2π)
# =============================================================================

if (FALSE) {   # Block wird beim Ausführen übersprungen

  # Installation (einmalig):
  # install.packages(c("remotes", "plyr", "rstatix", "doMC"))
  # remotes::install_github("maytesuarezfarinas/cosinoRmixedeffects")

  source("R/funktionen.R")
  library(cosinoRmixedeffects); library(lme4); library(emmeans)

  lr <- read_laufrad("daten/laufrad/TVR_11.xlsx")
  d  <- lr |> filter(!is.na(rad)) |>
    rename(Block = block, Group = gruppe) |> as.data.frame()

  # 1  rrr = cos(2πt/24), sss = sin(2πt/24) anlegen
  d <- create.cosinor.param(time = "t_h", period = 24, data = d)

  # 2  Modell: rad ~ Block*Group*(rrr + sss) + (1 + rrr + sss | id)
  fit <- fit.cosinor.mixed(y = "rad", interaction = c("Block", "Group"),
                           random = "1+rrr+sss|id", data = d)

  # 3  MESOR, Amplitude, Akrophase (rad), PeakTime (h) + Bootstrap-KI
  means <- get.means.ci.cosinor(fit, contrast.frm = "~Block|Group", nsim = 500)

  # 4  Paarweise Kontraste + p-Werte (nicht unter Windows, s. oben)
  deltas <- get.contrasts.ci.cosinor(fit, contrast.frm = "~Block|Group", nsim = 500)
}

# Die Punktschätzer sind identisch mit cos_zellen aus 02 – es ist dasselbe
# Modell, nur anders parametrisiert. Die Intervalle unterscheiden sich leicht:
# 02 zieht aus der Verteilung der festen Effekte (Sekunden), das Paket passt
# das ganze Modell neu an (Minuten bis Stunden).
