# =============================================================================
# 01_motionwatch.R – Hands-on A: Aktigraphie mit der MotionWatch 8
# =============================================================================
# Ablauf
#   1  Alle MotionWare-Exporte aus daten/motionwatch/ einlesen
#   2  Qualitätskontrolle: Wann fehlen Daten?
#   3  Auf Stunden aggregieren
#   4  Nichtparametrische Kennwerte: IS, IV, M10, L5, RA
#   5  Vergleich mit den Werten aus MotionWare
#   6  Cosinor
#   7  Abbildungen: Aktogramm, Polarplot, Scatterplot
#   8  Ergebnisse speichern
#
# Neue Uhren? Einfach die CSV-Exporte in daten/motionwatch/ legen und das
# Skript erneut ausführen – alle Schritte laufen über den ganzen Ordner.
#
# Export in MotionWare: Datei öffnen → Export der Rohdaten als CSV
# (oder „Bulk Export“ für einen ganzen Ordner von .mtn-Dateien).
# =============================================================================

source("R/funktionen.R")
dir.create("ergebnisse", showWarnings = FALSE)

# -----------------------------------------------------------------------------
# 1  Einlesen
# -----------------------------------------------------------------------------
mw <- read_motionwatch_ordner("daten/motionwatch")

mw                                   # eine Zeile pro Epoche (hier 30 s)
count(mw, id, epoche_s)              # wie viele Epochen pro Person?

# -----------------------------------------------------------------------------
# 2  Qualitätskontrolle
# -----------------------------------------------------------------------------
# MotionWatch schreibt "n/a", solange die Uhr noch nicht aufgezeichnet hat
# oder nicht getragen wurde. Wie viel fehlt – und wann?
mw |>
  group_by(id) |>
  summarise(beginn   = min(zeit), ende = max(zeit),
            dauer_h  = as.numeric(difftime(ende, beginn, units = "hours")),
            fehlend  = mean(is.na(aktivitaet)))

ggplot(mw, aes(zeit, aktivitaet)) +
  geom_line(linewidth = 0.2) +
  geom_rug(data = filter(mw, is.na(aktivitaet)), aes(zeit), inherit.aes = FALSE,
           colour = "#d9781f", sides = "b") +
  facet_wrap(~ id, ncol = 1) +
  labs(x = NULL, y = "Aktivität (MW counts)",
       title = "Rohdaten – orange: fehlende Epochen") +
  theme_minimal()

# AUFGABE 1: Bei welcher Person fehlt deutlich mehr als bei den anderen?
#            Was bedeutet das für IS und M10/L5?

# -----------------------------------------------------------------------------
# 3  Stundenwerte
# -----------------------------------------------------------------------------
std <- stunden_aggregieren(mw)
std
# summe  = Aktivitätssumme der Stunde (Basis für IS, IV, M10, L5)
# mittel = mittlere Aktivität pro Epoche (Basis für den Cosinor)
# Stunden mit fehlenden Epochen sind NA.

# -----------------------------------------------------------------------------
# 4  Nichtparametrische Kennwerte
# -----------------------------------------------------------------------------
np <- std |>
  arrange(id, stunde_start) |>
  group_by(id) |>
  reframe(npcra(summe, uhrzeit))
np

# -----------------------------------------------------------------------------
# 5  Vergleich mit MotionWare
# -----------------------------------------------------------------------------
# Nur möglich, wenn MotionWare-Ergebnisse vorliegen (nicht bei simulierten Daten)
ref_datei <- "daten/motionwatch_motionware_referenz.csv"
if (file.exists(ref_datei)) {
ref <- read.csv2(ref_datei)

vergleich <- np |>
  select(id, IS, IV, M10, L5, RA) |>
  pivot_longer(-id, names_to = "kennwert", values_to = "R") |>
  inner_join(
    ref |> select(id, IS, IV, M10, L5, RA) |>
      pivot_longer(-id, names_to = "kennwert", values_to = "MotionWare"),
    by = c("id", "kennwert"))
print(vergleich |> mutate(differenz = R - MotionWare), n = Inf)

print(ggplot(vergleich, aes(MotionWare, R, label = id)) +
  geom_abline(linetype = 2, colour = "grey60") +
  geom_point(size = 3, colour = "#3f6db5") +
  facet_wrap(~ kennwert, scales = "free") +
  labs(title = "Eigene Berechnung gegen MotionWare",
       subtitle = "Gestrichelt: perfekte Übereinstimmung") +
  theme_minimal())

# AUFGABE 2: M10 und L5 stimmen (fast) exakt, IS und IV weichen leicht ab.
#            Woran könnte das liegen? Tipp: Wie geht man mit fehlenden
#            Stunden um? Bei welcher Person ist die Abweichung am größten?
}

# -----------------------------------------------------------------------------
# 6  Cosinor
# -----------------------------------------------------------------------------
cos <- std |>
  filter(!is.na(mittel)) |>
  group_by(id) |>
  reframe(cosinor_lm(mittel, uhrzeit + 0.5))   # +0.5: Mitte der Stunde
cos

# AUFGABE 3: Vergleiche die Akrophase mit dem M10-Onset.
#            Warum liegen sie so weit auseinander? (Folie „Cosinor“ vs. „M10“)

# -----------------------------------------------------------------------------
# 7  Abbildungen
# -----------------------------------------------------------------------------
aktogramm(mw)
polarplot(std)

kennwerte <- np |>
  left_join(cos, by = "id") |>
  left_join(read.csv2("daten/motionwatch_fragebogen.csv"), by = "id")

ggplot(kennwerte, aes(IS, IV, colour = chronotyp, label = id)) +
  geom_point(size = 4) +
  geom_text(vjust = -1, size = 3, show.legend = FALSE) +
  labs(title = "Stabilität gegen Fragmentierung") +
  theme_minimal()

ggplot(kennwerte, aes(MEQ, M10_onset, label = id)) +
  geom_point(size = 4, colour = "#d9781f") +
  geom_text(vjust = -1, size = 3) +
  labs(x = "Morningness-Eveningness (MEQ)", y = "M10-Onset (Uhr)",
       title = "Chronotyp und Lage der aktivsten 10 Stunden") +
  theme_minimal()

# AUFGABE 4: Passt der Fragebogen zum gemessenen Verhalten?
#            Was müsste man bei nur 4 Messtagen einschränkend sagen?

# -----------------------------------------------------------------------------
# 8  Speichern (Semikolon + Dezimalkomma → öffnet direkt im deutschen Excel)
# -----------------------------------------------------------------------------
write.csv2(kennwerte, "ergebnisse/motionwatch_kennwerte.csv", row.names = FALSE)
ggsave("ergebnisse/motionwatch_aktogramm.png", aktogramm(mw),
       width = 12, height = 6, dpi = 200, bg = "white")
ggsave("ergebnisse/motionwatch_polarplot.png", polarplot(std),
       width = 8, height = 6, dpi = 200, bg = "white")

# =============================================================================
# Lösungshinweise
# =============================================================================
# 1  Person05: die Uhr zeichnet erst ab dem Morgen des zweiten Tags auf.
#    Damit fehlt ein ganzer Tag – IS beruht auf weniger Wiederholungen, und das
#    mittlere Profil der ersten Stunden stützt sich auf weniger Tage.
# 2  MotionWare und R behandeln unvollständige Stunden und die Lücken zwischen
#    gültigen Stunden nicht exakt gleich. Bei kleinen Lücken sind die
#    Unterschiede gering; bei großem Ausfall am größten.
#    Merke: Methode zur Behandlung fehlender Daten immer berichten.
# 3  Die Akrophase ist der Gipfel einer Sinuskurve, M10-Onset der BEGINN des
#    aktivsten 10-h-Fensters. Bei breitem Tagesplateau liegt die Akrophase
#    mehrere Stunden hinter dem M10-Onset.
# 4  Tendenz ja, aber: n = 5 Personen, 7 Tage – Kennwerte
#    wie IS sind bei so kurzen Aufzeichnungen unsicher (Empfehlung: ≥ 7 Tage).
