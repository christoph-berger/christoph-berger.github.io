# =============================================================================
# 00_setup.R – einmal VOR dem Workshop ausführen
# Installiert alle Pakete, die in den Workshop-Skripten verwendet werden.
# =============================================================================

pakete <- c(
  "dplyr", "tidyr", "ggplot2", "lubridate", "patchwork",  # Aufbereitung & Grafik
  "readxl",                                               # Excel (Laufraddaten)
  "lme4", "lmerTest", "emmeans"                           # Mixed Models
)
fehlend <- setdiff(pakete, rownames(installed.packages()))
if (length(fehlend) > 0) install.packages(fehlend)

# Test: alle Pakete ladbar?
ok <- sapply(pakete, requireNamespace, quietly = TRUE)
print(ok)
if (all(ok)) message("Alles bereit für den Workshop.") else
  message("Bitte fehlende Pakete prüfen: ", paste(names(ok)[!ok], collapse = ", "))
