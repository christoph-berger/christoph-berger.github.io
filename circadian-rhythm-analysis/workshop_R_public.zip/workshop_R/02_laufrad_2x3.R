# =============================================================================
# 02_laufrad_2x3.R – Hands-on B: Laufraddaten im 2 × 3-Design
# =============================================================================
# Simulierter Datensatz im Aufbau echter Laufraddaten: 21 Mäuse,
# stündliche Laufradsummen über 29 Versuchstage (keine echten Messwerte)
#   Gruppe (zwischen Tieren):  Control (K…) vs. Starvation (A…)
#   Block  (innerhalb Tieren): baseline → acute → chronic
#
# Ablauf
#   1  Einlesen und Zeitachse aufbauen
#   2  Exploration: Aktogramm und Polarplots
#   3  Kennwerte pro Tier und Block (IS, IV, RA, M10, L5, Cosinor)
#   4  Statistik der Kennwerte: Mixed Model + Kontraste
#   5  Mixed-Cosinor auf den Rohdaten
#   6  Ergebnisse speichern
# =============================================================================

source("R/funktionen.R")
library(lme4)
library(lmerTest)      # p-Werte für lmer-Modelle
library(emmeans)
library(patchwork)
dir.create("ergebnisse", showWarnings = FALSE)

# -----------------------------------------------------------------------------
# 1  Einlesen
# -----------------------------------------------------------------------------
datei_laufrad <- "daten/laufrad/laufrad_simuliert.xlsx"     # eigene Datei hier eintragen
lr <- read_laufrad(datei_laufrad)
lr
# rad    = Laufradumdrehungen in der Stunde
# stunde = Uhrzeit der Messstunde (0–23), t_h = Stundenmitte für den Cosinor
# rel    = Stunde im Versuchstag (0 = 14 Uhr … 22 = 12 Uhr)

lr |> distinct(id, gruppe) |> count(gruppe)              # Tiere pro Gruppe
lr |> distinct(versuchstag, block) |> count(block)       # Tage pro Block

# AUFGABE 1: Öffne die Excel-Datei und sieh dir die Spalte "Datum / Uhrzeit"
#            an. Warum bauen wir die Zeitachse aus Versuchstag + Uhrzeit auf,
#            statt die Zeitstempel direkt zu verwenden?

# -----------------------------------------------------------------------------
# 2  Exploration
# -----------------------------------------------------------------------------
# Aktogramm als Heatmap: Gruppenmittel, eine Zeile pro Versuchstag
akt <- lr |>
  group_by(gruppe, block, versuchstag, rel) |>
  summarise(rad = mean(rad, na.rm = TRUE), .groups = "drop")

ggplot(akt, aes(rel, versuchstag, fill = rad)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "#172033", name = "Umdrehungen\n/ Stunde") +
  scale_y_reverse(breaks = seq(1, 29, 4)) +
  scale_x_continuous(breaks = seq(0, 22, 4),
                     labels = paste0((seq(0, 22, 4) + 14) %% 24, " Uhr")) +
  facet_wrap(~ gruppe) +
  geom_hline(yintercept = c(10.5, 16.5), colour = "#d9781f", linewidth = 0.6) +
  labs(x = NULL, y = "Versuchstag",
       title = "Aktogramm (Gruppenmittel)",
       subtitle = "Orange: Wechsel baseline → acute → chronic") +
  theme_minimal()

# Polarplots: mittleres 24-h-Profil pro Zelle des 2 × 3-Designs
prof <- lr |>
  group_by(gruppe, block, stunde) |>
  summarise(rad = mean(rad, na.rm = TRUE), .groups = "drop")

ggplot(prof, aes(stunde + 0.5, rad)) +
  geom_col(width = 1, fill = "#3f6db5", alpha = 0.85) +
  coord_polar(start = 0) +
  scale_x_continuous(limits = c(0, 24), breaks = seq(0, 18, 6)) +
  facet_grid(gruppe ~ block) +
  labs(x = "Uhrzeit (h)", y = NULL, title = "Mittleres Tagesprofil") +
  theme_minimal() + theme(axis.text.y = element_blank())

# AUFGABE 2: Was verändert sich unter Starvation – Menge, Lage oder Form
#            der Aktivität? Was davon würde der Cosinor erfassen?

# -----------------------------------------------------------------------------
# 3  Kennwerte pro Tier und Block
# -----------------------------------------------------------------------------
voll <- laufrad_vervollstaendigen(lr)     # fehlende Stunden als NA

kw_np <- voll |>
  group_by(id, gruppe, block) |>
  reframe(npcra(rad, stunde))

kw_cos <- lr |>
  filter(!is.na(rad)) |>
  group_by(id, gruppe, block) |>
  reframe(cosinor_lm(rad, t_h))

kw <- left_join(kw_np, kw_cos, by = c("id", "gruppe", "block"))
kw

# Überblick: jeder Punkt ein Tier
kw |>
  select(id, gruppe, block, IS, IV, RA, Amplitude) |>
  pivot_longer(c(IS, IV, RA, Amplitude), names_to = "kennwert") |>
  ggplot(aes(block, value, colour = gruppe, group = interaction(id))) +
  geom_line(alpha = 0.3) +
  geom_point(alpha = 0.6) +
  stat_summary(aes(group = gruppe), fun = mean, geom = "line", linewidth = 1.3) +
  facet_wrap(~ kennwert, scales = "free_y") +
  scale_colour_manual(values = c(Control = "#3f6db5", Starvation = "#d9781f")) +
  labs(x = NULL, y = NULL, title = "Kennwerte pro Tier – dünne Linien: einzelne Tiere") +
  theme_minimal()

# Scatterplot: Stabilität gegen Fragmentierung
ggplot(kw, aes(IS, IV, colour = block, shape = gruppe)) +
  geom_point(size = 3, alpha = 0.8) +
  labs(title = "IS gegen IV, alle Tiere und Blöcke") +
  theme_minimal()

# -----------------------------------------------------------------------------
# 4  Statistik der Kennwerte
# -----------------------------------------------------------------------------
# Messwiederholung: jedes Tier liefert drei Werte (einen pro Block)
# → zufälliger Achsenabschnitt pro Tier.
m_is <- lmer(IS ~ gruppe * block + (1 | id), data = kw)
anova(m_is)                                   # Haupteffekte + Interaktion

em_is <- emmeans(m_is, ~ block | gruppe)
pairs(em_is, adjust = "holm")                 # Blockvergleiche innerhalb jeder Gruppe
pairs(emmeans(m_is, ~ gruppe | block))        # Gruppenvergleich in jedem Block

# Dasselbe für alle Kennwerte auf einmal
kennwerte <- c("IS", "IV", "RA", "M10", "L5", "Amplitude", "MESOR")
anova_alle <- lapply(kennwerte, function(k) {
  m <- lmer(reformulate("gruppe * block + (1 | id)", k), data = kw)
  a <- as.data.frame(anova(m))
  tibble(kennwert = k, effekt = rownames(a), F = a$`F value`, p = a$`Pr(>F)`)
}) |> bind_rows()
anova_alle |> mutate(across(c(F, p), \(x) round(x, 3))) |> print(n = Inf)

# AUFGABE 3: Rechne die Analyse für IV. Ändert sich die Fragmentierung unter
#            akuter oder chronischer Starvation – und nur in der A-Gruppe?

# -----------------------------------------------------------------------------
# 5  Mixed-Cosinor auf den Rohdaten
# -----------------------------------------------------------------------------
# Folie „Cosinor“: y = M + β·cos(2πt/24) + γ·sin(2πt/24)
# Hier bekommt jede der 6 Zellen eigene M, β, γ; jedes Tier darf zusätzlich
# eigenes Niveau, eigene Amplitude und eigene Phase haben (zufällige Effekte).
d_cos <- lr |>
  filter(!is.na(rad)) |>
  mutate(rrr   = cos(2 * pi * t_h / 24),
         sss   = sin(2 * pi * t_h / 24),
         zelle = interaction(block, gruppe, sep = ","))

fit_cos <- lmer(rad ~ 0 + zelle + zelle:rrr + zelle:sss + (1 + rrr + sss | id),
                data = d_cos,
                control = lmerControl(optimizer = "bobyqa"))   # stabilerer Optimierer

cos_zellen <- cosinor_zellen(fit_cos) |>
  mutate(block = factor(block, levels(lr$block)),
         gruppe = factor(gruppe, levels(lr$gruppe)))
cos_zellen |> mutate(across(where(is.numeric), \(x) round(x, 1))) |> print(n = Inf)

# Abbildung: geschätzte Parameter mit 95-%-Intervall
ggplot(cos_zellen, aes(block, schaetzer, colour = gruppe)) +
  geom_pointrange(aes(ymin = ki_unten, ymax = ki_oben),
                  position = position_dodge(width = 0.4)) +
  facet_wrap(~ parameter, scales = "free_y") +
  scale_colour_manual(values = c(Control = "#3f6db5", Starvation = "#d9781f")) +
  labs(x = NULL, y = "Schätzer (95-%-Intervall)",
       title = "Mixed-Cosinor: MESOR, Amplitude, Akrophase") +
  theme_minimal()

# Abbildung: Cosinor-Kurven über den Stundenmitteln
kurven <- cos_zellen |>
  select(zelle, block, gruppe, parameter, schaetzer) |>
  pivot_wider(names_from = parameter, values_from = schaetzer) |>
  crossing(t = seq(0, 24, 0.1)) |>
  mutate(y = MESOR + Amplitude * cos(2 * pi * (t - Akrophase_h) / 24),
         block = factor(block, levels(lr$block)),
         gruppe = factor(gruppe, levels(lr$gruppe)))

ggplot() +
  geom_point(data = prof, aes(stunde + 0.5, rad), colour = "grey55", size = 1.2) +
  geom_line(data = kurven, aes(t, y, colour = gruppe), linewidth = 1.1) +
  geom_hline(data = distinct(kurven, block, gruppe, MESOR),
             aes(yintercept = MESOR), linetype = 2, colour = "grey40") +
  facet_grid(gruppe ~ block) +
  scale_colour_manual(values = c(Control = "#3f6db5", Starvation = "#d9781f"),
                      guide = "none") +
  scale_x_continuous(breaks = seq(0, 24, 6)) +
  labs(x = "Uhrzeit (h)", y = "Laufrad / Stunde",
       title = "Cosinor-Kurven (Linie) und Stundenmittel (Punkte)") +
  theme_minimal()

# Vergleiche: Blöcke innerhalb jeder Gruppe, Gruppen innerhalb jedes Blocks
paare <- list(
  c("baseline,Control",    "acute,Control"),
  c("baseline,Control",    "chronic,Control"),
  c("baseline,Starvation", "acute,Starvation"),
  c("baseline,Starvation", "chronic,Starvation"),
  c("baseline,Control",    "baseline,Starvation"),
  c("acute,Control",       "acute,Starvation"),
  c("chronic,Control",     "chronic,Starvation"))
cos_kontraste <- cosinor_kontraste(fit_cos, paare)
cos_kontraste |>
  mutate(across(where(is.numeric), \(x) round(x, 3))) |>
  print(n = Inf)

# AUFGABE 4: Die Punkte (Stundenmittel) liegen bei manchen Zellen deutlich
#            neben der Kurve. Was sagt uns das über die Annahmen des Cosinors
#            bei Laufraddaten? Welcher Kennwert aus Schritt 3 ist davon nicht
#            betroffen?

# -----------------------------------------------------------------------------
# 6  Speichern
# -----------------------------------------------------------------------------
write.csv2(kw,            "ergebnisse/laufrad_kennwerte_pro_tier.csv", row.names = FALSE)
write.csv2(anova_alle,    "ergebnisse/laufrad_anova_kennwerte.csv",   row.names = FALSE)
write.csv2(cos_zellen,    "ergebnisse/laufrad_cosinor_zellen.csv",    row.names = FALSE)
write.csv2(cos_kontraste, "ergebnisse/laufrad_cosinor_kontraste.csv", row.names = FALSE)

# =============================================================================
# Lösungshinweise
# =============================================================================
# 1  Ein Teil der Zeitstempel ist Text im US-Format, ein Teil wurde von Excel
#    in ein Datum umgewandelt – mit vertauschtem Tag und Monat (12.04. wird
#    zum 4. Dezember). Außerdem: ein AM/PM-Fehler (Tag 3) und ausgeschlossene
#    Tage (Lücken im Kalender). Die Uhrzeit ist dagegen
#    zuverlässig, und der Versuchstag gibt die Reihenfolge vor.
# 2  Unter Starvation steigt typischerweise die Gesamtaktivität, und die
#    Aktivität verlagert sich teilweise in die Hellphase (Antizipation der
#    Fütterung). Menge → MESOR; Lage → Akrophase; Form (zweiter Gipfel)
#    erfasst der einfache Cosinor NICHT.
# 3  m_iv <- lmer(IV ~ gruppe * block + (1 | id), data = kw); anova(m_iv);
#    pairs(emmeans(m_iv, ~ block | gruppe)). Interpretation: Interaktion
#    gruppe:block entscheidet, ob sich nur die A-Gruppe verändert.
# 4  Laufradprofile sind eher rechteckig oder zweigipflig, nicht sinusförmig.
#    Der Cosinor glättet das weg – Amplitude und Akrophase beschreiben dann
#    nur die beste Sinusnäherung. IS, IV, M10 und L5 setzen keine Kurvenform
#    voraus (Folie „Operationalisierung“).
