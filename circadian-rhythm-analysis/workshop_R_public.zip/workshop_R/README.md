# Workshop: Zirkadiane Rhythmen analysieren mit R

## Vor dem Workshop
1. R (≥ 4.2) und RStudio installieren.
2. Diesen Ordner entpacken und `workshop_R.Rproj` öffnen.
3. `00_setup.R` einmal komplett ausführen. Am Ende sollte „Alles bereit für den Workshop.“ erscheinen.

## Inhalt
| Datei / Ordner | Inhalt |
|---|---|
| `R/funktionen.R` | Alle Funktionen: Einlesen, Stundenwerte, IS/IV/M10/L5/RA, Cosinor, Aktogramm, Polarplot |
| `01_motionwatch.R` | Hands-on A: MotionWatch 8 – vom Rohexport zu Kennwerten und Abbildungen |
| `02_laufrad_2x3.R` | Hands-on B: Laufraddaten, 2 Gruppen × 3 Bedingungen – Kennwerte, Mixed Models, Mixed-Cosinor |
| `03_ausblick_cosinor_paket.R` | Ausblick (nicht ausführen): dasselbe Modell mit `cosinoRmixedeffects` |
| `daten/motionwatch/` | MotionWare-Rohdatenexporte (CSV), eine Datei pro Person |
| `daten/motionwatch_fragebogen.csv` | Chronotyp-Fragebogen (MEQ) |
| `daten/laufrad/laufrad_simuliert.xlsx` | Simulierte Laufraddaten: 21 Mäuse, Kontrolle vs. Starvation, baseline / acute / chronic |
| `ergebnisse/` | Hier landen Tabellen und Abbildungen |

## Eigene oder neue MotionWatch-Daten
In MotionWare die Rohdaten als CSV exportieren und in `daten/motionwatch/` ablegen.
`01_motionwatch.R` liest automatisch alle CSV-Dateien des Ordners.
Für neue Personen fehlen die MotionWare-Referenzwerte – der Vergleich in Schritt 5
zeigt dann nur die Personen, die in der Referenztabelle stehen.

**Alle Daten in dieser Version sind simuliert.** Sie haben denselben Aufbau wie echte MotionWare-Exporte und Laufrad-Tabellen, einschließlich typischer Stolperfallen (Dezimalkomma bei Licht, gemischte Datumsformate, AM/PM-Fehler). Der Vergleich mit MotionWare-Werten (Schritt 5 in 01) entfällt, weil es dafür keine Herstellerausgabe gibt.
