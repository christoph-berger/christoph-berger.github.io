# =============================================================================
# funktionen.R – gemeinsame Funktionen für den Workshop
# Die Formeln entsprechen eins zu eins den Folien (Block 2).
# =============================================================================

library(dplyr)
library(tidyr)
library(ggplot2)
library(lubridate)

# -----------------------------------------------------------------------------
# 1  MotionWatch-8-Export (MotionWare, CSV) einlesen
# -----------------------------------------------------------------------------
# Aufbau der Datei:
#   - Kopfzeilen mit Metadaten ("UserID,Praktikant1", "Motion epoch (s),30", ...)
#   - Zeile "Raw data:"
#   - Spaltenkopf "Date,Time,Activity (MW counts),Light (lux)"
#   - Daten, fehlende Werte als "n/a"
#
# Stolperfalle: Auf deutschen Rechnern schreibt MotionWare die Lichtwerte mit
# Dezimalkomma ("158,39,5125" = Aktivität 158, Licht 39.5125). Ein normales
# read.csv() zerlegt die Zeile dann in zu viele Spalten. Deshalb trennen wir
# nur an den ersten drei Kommas und behandeln den Rest als Lichtwert.
#
# Zeitzone: Die Uhr speichert ihre interne Uhrzeit ohne Sommer-/Winterzeit-
# Umstellung. Wir lesen deshalb als "UTC" ein, damit R keine Stunden einfügt
# oder löscht. Die angezeigte Uhrzeit bleibt die Uhrzeit der MotionWatch.

read_motionwatch <- function(pfad) {
  zeilen <- readLines(pfad, encoding = "UTF-8", warn = FALSE)
  zeilen <- sub("^\ufeff", "", zeilen)                   # Byte-Order-Mark entfernen
  kopf   <- grep("^Date,Time,Activity", zeilen)
  if (length(kopf) != 1) stop("Kein Datenkopf gefunden in: ", pfad)

  # Metadaten: alles vor "Raw data:" im Format Schlüssel,Wert
  meta_z <- zeilen[seq_len(kopf - 1)]
  meta_z <- meta_z[grepl(",", meta_z)]
  meta   <- setNames(sub("^[^,]*,", "", meta_z), sub(",.*$", "", meta_z))

  daten  <- zeilen[(kopf + 1):length(zeilen)]
  daten  <- daten[nzchar(daten)]
  teile  <- do.call(rbind, regmatches(daten,
              regexec("^([^,]*),([^,]*),([^,]*),?(.*)$", daten)))

  zahl <- function(x) {
    x[x %in% c("n/a", "")] <- NA
    as.numeric(sub(",", ".", x, fixed = TRUE))
  }

  tibble(
    datei      = basename(pfad),
    id         = unname(meta["UserID"]),
    zeit       = parse_date_time(paste(teile[, 2], teile[, 3]),
                                 orders = c("Ymd HMS", "dmY HMS"), tz = "UTC"),
    aktivitaet = zahl(teile[, 4]),
    licht      = zahl(teile[, 5]),
    epoche_s   = as.numeric(meta["Motion epoch (s)"])
  )
}

# Alle CSV-Dateien eines Ordners einlesen und untereinander hängen
read_motionwatch_ordner <- function(ordner) {
  dateien <- list.files(ordner, pattern = "\\.csv$", full.names = TRUE)
  if (length(dateien) == 0) stop("Keine CSV-Dateien in ", ordner)
  message(length(dateien), " Datei(en) gefunden: ",
          paste(basename(dateien), collapse = ", "))
  bind_rows(lapply(dateien, read_motionwatch))
}

# -----------------------------------------------------------------------------
# 2  Auf Stunden aggregieren
# -----------------------------------------------------------------------------
# Eine Stunde zählt nur, wenn ALLE Epochen gültig sind (so rechnet MotionWare;
# damit stimmen M10 und L5 exakt mit der Herstellersoftware überein).
# Analysezeitraum: erste volle Stunde nach Beginn bis letzte volle Stunde.

stunden_aggregieren <- function(df) {
  df |>
    group_by(id) |>
    mutate(beginn = ceiling_date(min(zeit), "hour"),
           ende   = floor_date(max(zeit) + seconds(first(epoche_s)), "hour")) |>
    filter(zeit >= beginn, zeit < ende) |>
    mutate(stunde_start = floor_date(zeit, "hour")) |>
    group_by(id, stunde_start) |>
    summarise(
      n_gueltig  = sum(!is.na(aktivitaet)),
      n_soll     = 3600 / first(epoche_s),
      summe      = ifelse(n_gueltig == n_soll, sum(aktivitaet), NA_real_),
      mittel     = ifelse(n_gueltig == n_soll, mean(aktivitaet), NA_real_),
      licht      = mean(licht, na.rm = TRUE),
      .groups = "drop"
    ) |>
    mutate(uhrzeit = hour(stunde_start),
           tag     = as.Date(stunde_start))
}

# -----------------------------------------------------------------------------
# 3  Nichtparametrische Kennwerte (Folien „M10/L5“, „RA“, „IS“, „IV“)
# -----------------------------------------------------------------------------
# x       : Stundenwerte in zeitlicher Reihenfolge (NA = ungültige Stunde)
# uhrzeit : zugehörige Uhrzeit 0–23

npcra <- function(x, uhrzeit) {
  ok  <- !is.na(x)
  xx  <- x[ok]; n <- length(xx); xm <- mean(xx)

  # Interdaily Stability:  IS = n · Σh (x̄h − x̄)² / (p · Σi (xi − x̄)²)
  # p = Anzahl der Stunden pro Tag, für die es Daten gibt (normal 24; bei den
  # Laufraddaten 23, weil die Stunde 13–14 Uhr nie gemessen wird)
  xh  <- tapply(xx, uhrzeit[ok], mean)
  p   <- length(xh)
  IS  <- n * sum((xh - xm)^2) / (p * sum((xx - xm)^2))

  # Intradaily Variability: nur Differenzen zwischen zwei gültigen Nachbarstunden
  d   <- diff(x); d <- d[!is.na(d)]
  IV  <- n * sum(d^2) / ((n - 1) * sum((xx - xm)^2))

  # M10 / L5 aus dem mittleren 24-h-Profil, Fenster laufen über Mitternacht
  profil  <- rep(NA_real_, 24); profil[as.integer(names(xh)) + 1] <- xh
  fenster <- function(k) sapply(0:23, function(s)
               mean(profil[((s:(s + k - 1)) %% 24) + 1], na.rm = TRUE))
  m10 <- fenster(10); l5 <- fenster(5)

  tibble(
    n_stunden = n,
    IS = IS, IV = IV,
    M10 = max(m10), M10_onset = which.max(m10) - 1,
    L5  = min(l5),  L5_onset  = which.min(l5) - 1,
    RA  = (max(m10) - min(l5)) / (max(m10) + min(l5))
  )
}

# -----------------------------------------------------------------------------
# 4  Cosinor als lineares Modell (Folie „Cosinor“)
# -----------------------------------------------------------------------------
# y(t) = M + β·cos(2πt/τ) + γ·sin(2πt/τ) + ε
# A = √(β² + γ²),  φ = atan2(−γ, β),  Akrophase (h) = (−φ · τ / 2π) mod τ

cosinor_lm <- function(y, t, tau = 24) {
  fit <- lm(y ~ cos(2 * pi * t / tau) + sin(2 * pi * t / tau))
  b   <- coef(fit); s <- summary(fit)
  phi <- atan2(-b[3], b[2])
  f   <- s$fstatistic
  tibble(
    MESOR       = unname(b[1]),
    Amplitude   = unname(sqrt(b[2]^2 + b[3]^2)),
    Akrophase_h = unname((-phi * tau / (2 * pi)) %% tau),
    R2          = s$r.squared,
    p_Wert      = unname(pf(f[1], f[2], f[3], lower.tail = FALSE))
  )
}

# -----------------------------------------------------------------------------
# 5  Abbildungen
# -----------------------------------------------------------------------------

# Doppelt geplottetes Aktogramm: jede Zeile zeigt Tag n und Tag n+1
aktogramm <- function(df, bin_min = 10, mit_licht = TRUE) {
  b <- df |>
    filter(!is.na(aktivitaet)) |>
    mutate(bin = floor_date(zeit, paste(bin_min, "mins"))) |>
    group_by(id, bin) |>
    summarise(akt = sum(aktivitaet),
              lux = mean(licht, na.rm = TRUE), .groups = "drop") |>
    mutate(tag = as.Date(bin),
           h   = hour(bin) + minute(bin) / 60)
  doppel <- bind_rows(
    b,
    b |> mutate(tag = tag - 1, h = h + 24)   # zweite Hälfte: Folgetag rechts
  ) |>
    group_by(id) |> filter(tag >= min(b$tag)) |> ungroup() |>
    group_by(id) |> mutate(akt_rel = akt / max(akt)) |> ungroup()

  p <- ggplot(doppel)
  if (mit_licht) {
    p <- p + geom_col(aes(h + bin_min / 120, log10(lux + 1) / 5),
                      width = bin_min / 60, fill = "#f2c14e", alpha = 0.45)
  }
  p +
    geom_col(aes(h + bin_min / 120, akt_rel),
             width = bin_min / 60, fill = "#172033") +
    facet_grid(tag ~ id, switch = "y") +
    scale_x_continuous(breaks = seq(0, 48, 6), expand = c(0, 0)) +
    scale_y_continuous(breaks = NULL) +
    labs(x = "Uhrzeit (h), doppelt geplottet", y = NULL,
         caption = if (mit_licht) "Gelb: Licht (log-skaliert)" else NULL) +
    theme_minimal(base_size = 11) +
    theme(strip.text.y.left = element_text(angle = 0),
          panel.spacing.y = unit(0, "pt"),
          panel.grid.minor = element_blank())
}

# Polarplot des mittleren 24-h-Profils
polarplot <- function(stunden) {
  prof <- stunden |>
    filter(!is.na(summe)) |>
    group_by(id, uhrzeit) |>
    summarise(akt = mean(summe), .groups = "drop")
  ggplot(prof, aes(uhrzeit + 0.5, akt)) +
    geom_col(width = 1, fill = "#3f6db5", alpha = 0.8) +
    coord_polar(start = 0) +
    scale_x_continuous(limits = c(0, 24), breaks = seq(0, 18, 6)) +
    facet_wrap(~ id) +
    labs(x = "Uhrzeit (h)", y = NULL,
         caption = "Radius: mittlere Aktivitätssumme pro Stunde") +
    theme_minimal(base_size = 11) +
    theme(axis.text.y = element_blank())
}

# -----------------------------------------------------------------------------
# 6  Laufraddaten (Excel, eine Spalte pro Tier) einlesen – Teil B
# -----------------------------------------------------------------------------
# Aufbau: Versuchstag | Tag im Block | Block | Datum / Uhrzeit | A132 … | K121 …
# Ein Versuchstag läuft von 14 Uhr bis 13 Uhr des Folgetags (23 Stundenwerte;
# 13–14 Uhr fehlt immer). Jeder Wert ist die Laufradsumme der vorangehenden
# Stunde (Zeitstempel 15:59:59 = Stunde 15–16 Uhr).
#
# Stolperfalle Datum: Die Zeitstempel liegen gemischt vor – teils als Text im
# US-Format ("4/13/2023 9:59:59 PM"), teils als von Excel umgewandeltes Datum,
# bei dem Tag und Monat vertauscht sein können. Wir vertrauen deshalb nur der
# UHRZEIT und bauen die Zeitachse aus Versuchstag + Stunde auf.

read_laufrad <- function(pfad, blatt = 1) {
  roh <- readxl::read_excel(pfad, sheet = blatt, col_types = "text")
  ts  <- roh[["Datum / Uhrzeit"]]

  # Uhrzeit in Stunden (dezimal) – aus Excel-Seriennummer ODER Text
  seriell <- suppressWarnings(as.numeric(ts))
  uhr <- ifelse(!is.na(seriell),
                (seriell %% 1) * 24,
                { t <- parse_date_time(ts, "mdY IMS p", tz = "UTC", quiet = TRUE)
                  hour(t) + minute(t) / 60 + second(t) / 3600 })

  # Messstunde: Zeitstempel kurz vor/nach der vollen Stunde → vorherige Stunde
  stunde <- (round(uhr) - 1) %% 24

  tiere <- grep("^[AK][0-9]+$", names(roh), value = TRUE)
  d <- roh |>
    mutate(versuchstag = as.integer(Versuchstag), block_roh = Block,
           stunde = stunde) |>
    select(versuchstag, block_roh, stunde, all_of(tiere))

  # Plausibilitätsprüfung: innerhalb eines Versuchstags muss die Stunde
  # (gezählt ab 14 Uhr) streng ansteigen. Typischer Fehler: AM/PM vertauscht.
  d <- d |>
    group_by(versuchstag) |>
    mutate(rel = (stunde - 14) %% 24,
           fehler = rel <= lag(rel, default = -1),
           stunde = ifelse(fehler, (stunde + 12) %% 24, stunde),
           rel = (stunde - 14) %% 24) |>
    ungroup()
  if (any(d$fehler)) message("Korrigiert (AM/PM): Versuchstag ",
                             paste(unique(d$versuchstag[d$fehler]), collapse = ", "))

  d |>
    select(-fehler) |>
    pivot_longer(all_of(tiere), names_to = "id", values_to = "rad") |>
    mutate(
      rad   = as.numeric(rad),
      gruppe = factor(ifelse(grepl("^A", id), "Starvation", "Control"),
                      levels = c("Control", "Starvation")),
      block = factor(case_when(
                grepl("Eingew", block_roh) ~ "baseline",
                grepl("^[Aa]kut", block_roh) ~ "acute",
                grepl("^[Cc]hron", block_roh) ~ "chronic",
                grepl("Wiederauff", block_roh) ~ "refeed",
                TRUE ~ block_roh),
              levels = c("baseline", "acute", "chronic", "refeed")) |> droplevels(),
      t_h   = stunde + 0.5                     # Mitte der Messstunde
    ) |>
    select(id, gruppe, block, versuchstag, stunde, rel, t_h, rad) |>
    arrange(id, versuchstag, rel)
}

# Fehlende Stunden als NA einfügen (für IV: keine Differenz über Lücken)
laufrad_vervollstaendigen <- function(d) {
  d |>
    select(id, gruppe, block, versuchstag, rel, rad) |>
    complete(nesting(id, gruppe), nesting(versuchstag, block), rel = 0:23) |>
    mutate(stunde = (rel + 14) %% 24) |>
    arrange(id, versuchstag, rel)
}

# -----------------------------------------------------------------------------
# 7  Mixed-Cosinor: Parameter pro Zelle aus den festen Effekten
# -----------------------------------------------------------------------------
# Modell: rad ~ 0 + zelle + zelle:rrr + zelle:sss + (1 + rrr + sss | id)
# Für jede Zelle liefert das Modell MESOR, β (rrr) und γ (sss).
# Unsicherheit: Wir ziehen viele plausible Koeffizientensätze aus der
# geschätzten Verteilung der festen Effekte (multivariate Normalverteilung)
# und rechnen jede Ziehung in Amplitude und Akrophase um. Das ist deutlich
# schneller als ein Bootstrap, der das Modell hunderte Male neu anpasst.

cosinor_zellen <- function(fit, n_sim = 2000, tau = 24, seed = 1) {
  set.seed(seed)
  b   <- lme4::fixef(fit)
  sim <- MASS::mvrnorm(n_sim, b, as.matrix(vcov(fit)))
  zellen <- sub("^zelle", "", grep("^zelle[^:]*$", names(b), value = TRUE))

  param <- function(v, z) {
    v  <- rbind(v)                       # Vektor oder Matrix → Matrix
    M  <- v[, paste0("zelle", z)]
    be <- v[, paste0("zelle", z, ":rrr")]
    ga <- v[, paste0("zelle", z, ":sss")]
    cbind(MESOR = M, Amplitude = sqrt(be^2 + ga^2),
          Akrophase_h = (-atan2(-ga, be) * tau / (2 * pi)) %% tau)
  }
  zirk <- function(x, ref) ((x - ref + tau / 2) %% tau) - tau / 2   # Abstand im Kreis

  lapply(zellen, function(z) {
    pt <- param(b, z); ps <- param(sim, z)
    rel_ak <- zirk(ps[, "Akrophase_h"], pt[, "Akrophase_h"])
    tibble(
      zelle = z,
      parameter = c("MESOR", "Amplitude", "Akrophase_h"),
      schaetzer = as.numeric(pt),
      ki_unten  = c(quantile(ps[, 1], .025), quantile(ps[, 2], .025),
                    (pt[, 3] + quantile(rel_ak, .025)) %% tau),
      ki_oben   = c(quantile(ps[, 1], .975), quantile(ps[, 2], .975),
                    (pt[, 3] + quantile(rel_ak, .975)) %% tau)
    )
  }) |>
    bind_rows() |>
    tidyr::separate(zelle, c("block", "gruppe"), sep = ",", remove = FALSE)
}

# Paarweise Vergleiche zwischen Zellen (Differenz + KI + p aus den Ziehungen)
cosinor_kontraste <- function(fit, paare, n_sim = 2000, tau = 24, seed = 1) {
  set.seed(seed)
  b   <- lme4::fixef(fit)
  sim <- MASS::mvrnorm(n_sim, b, as.matrix(vcov(fit)))
  werte <- function(z) {
    M <- sim[, paste0("zelle", z)]
    be <- sim[, paste0("zelle", z, ":rrr")]; ga <- sim[, paste0("zelle", z, ":sss")]
    cbind(MESOR = M, Amplitude = sqrt(be^2 + ga^2),
          Akrophase_h = (-atan2(-ga, be) * tau / (2 * pi)) %% tau)
  }
  bind_rows(lapply(paare, function(pr) {
    d <- werte(pr[2]) - werte(pr[1])
    d[, 3] <- ((d[, 3] + tau / 2) %% tau) - tau / 2     # Phasendifferenz −12…+12 h
    tibble(vergleich = paste(pr[2], "vs", pr[1]),
           parameter = colnames(d),
           differenz = apply(d, 2, median),
           ki_unten  = apply(d, 2, quantile, .025),
           ki_oben   = apply(d, 2, quantile, .975),
           p_wert    = apply(d, 2, function(x) min(1, 2 * min(mean(x > 0), mean(x < 0)))))
  }))
}
